Proyecto de ejemplo - Practica
Incluye:
- Busqueda por nombre/edad (Buscar)
- Editar, Eliminar
- Ordenar por nombre
- Promedio de edad
Bases: .NET 7, EF Core (SQLite)
